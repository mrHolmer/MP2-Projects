package main;

public class Requirements2 {
    public String toString(){
        return "HI";
    }
}