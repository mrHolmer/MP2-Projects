package main;

public class Dimension {

}
